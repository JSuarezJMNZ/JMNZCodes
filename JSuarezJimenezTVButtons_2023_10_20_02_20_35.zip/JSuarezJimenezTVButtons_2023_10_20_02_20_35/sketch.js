var x = 220
var y = 350
var radius = 15

function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(220);
  
  fill(242, 91, 80);
  rect(100, 100, 300, 200);
  
  fill(0, 0, 0);
  rect(230, 300, 50, 30);
  
  fill(242, 91, 80);
  rect(175, 325, 155, 50);
  
  fill(255, 255, 255);
  rect(113, 109, 275, 183);
  
  ellipse(310, 350, 15, 15);
  
  {
    
  if (mouseIsPressed == true)  
  if ((mouseX > 186) && (mouseX < 186+15) &&
      (mouseY > 343) && (mouseY < 343+15)) {
    fill(0);
    }
    else {
      fill(255);
    }
    rect(186, 343, 15, 15);
  }
  
  if (mouseIsPressed == true)
  var d = dist(mouseX, mouseY, x, y);
  if (d < radius) {
    radius;
    fill(0);
  } else {
    fill(255);
  }
  ellipse(x, y, radius, radius);
  
  
   if (keyIsPressed) {
     if ((key == 'b') || (key == 'B')) {
      fill(0)
     }
  }
   ellipse(310, 350, radius, radius);
}