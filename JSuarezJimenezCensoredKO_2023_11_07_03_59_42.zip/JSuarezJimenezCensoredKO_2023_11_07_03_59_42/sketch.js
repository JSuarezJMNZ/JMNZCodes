var img1;
var img2;

function preload() {
  img1 = loadImage("fea.jpg");
  img2 = loadImage("fluffy.jpg");
                   
}

function setup() {
  createCanvas(550, 550);
  textFont("Gotham");
  fill(0);
  stroke(300);
}

function draw() {
  background(120);
  
  textSize(25);
  text("THE LEGS ARE GONE...", 150, 350);
  textSize(35);
  text("THIS FIGHT IS OVER!", 150, 450);
  
  image(img1, 0, 0, mouseX, mouseY);
  image(img2, 0, 0, 250, 250)

}