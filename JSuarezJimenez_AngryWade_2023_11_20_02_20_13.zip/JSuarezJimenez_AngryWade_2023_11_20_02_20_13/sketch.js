const density = 'Ñ@#W$9876543210?abc;:+=-,._ ';

let Wadeangry;

function preload() {
  Wadeangry = loadImage("Wadeangry.jpg");
}

function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(0);
  //image(Wadeangry, 0, 0, width, height);
  Wadeangry.loadPixels();
  let w = width / Wadeangry.width;
  let h = height / Wadeangry.height;
  
  for (let i = 0; i < Wadeangry.width; i++) {
    for (let j = 0; j < Wadeangry.height; j++) {
      const pixelIndex = (i + j * Wadeangry.width) * 4;
      const r = Wadeangry.pixels[pixelIndex + 0];
      const g = Wadeangry.pixels[pixelIndex + 1];
      const b = Wadeangry.pixels[pixelIndex + 2];
      const avg = (r + g + b) / 3;
      
      noStroke();
      fill(255);
      //square(i * w, j * h, w);
      
      const len = density.length;
      const charIndex = floor(map(avg, 0, 255, len, 0));
      
      textSize(w);
      textAlign(CENTER, CENTER)
      text(density.charAt(charIndex), i * w + w * 0.5, j * h + h * 0.5);
      
    }
  }
}